#ifndef __INC__NFILE
#define __INC__NFILE
#define _NFILE_	20
#endif
