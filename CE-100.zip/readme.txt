    2OS CE
    ------

 Dentro de este directorio encontrara todos los fuentes del
proyecto 2OS CE. Este sistema operativo, es un sistema UNIX
para dispositivos embebidos basados en tecnologia I386.

